var canvas = document.querySelector('canvas') ;

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

var c = canvas.getContext('2d');

c. fillRect(100, 100, 100, 100);
c. fillRect(300, 200, 100, 100);
c. fillRect(100, 200, 100, 100);
c. fillRect(300, 100, 100, 100);
c. fillRect(400, 300, 100, 100);
c. fillRect(200, 100, 100, 100);
c. fillRect(300, 400, 100, 100);
c. fillRect(400, 200, 100, 100);
c. fillRect(300, 500, 100, 100);
console. log(canvas);